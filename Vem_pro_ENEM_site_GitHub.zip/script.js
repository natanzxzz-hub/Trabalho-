const menuBtn=document.getElementById("menuBtn");
const menu=document.getElementById("menu");
menuBtn.addEventListener("click",()=>menu.classList.toggle("ativo"));
document.querySelectorAll("#menu a").forEach(link=>link.addEventListener("click",()=>menu.classList.remove("ativo")));

const perguntas=[
 {q:"Qual matéria faz parte da área de Ciências Humanas?",a:["História","Física","Química","Biologia"],c:0},
 {q:"Qual área do ENEM possui Matemática?",a:["Linguagens","Matemática","Ciências Humanas","Redação"],c:1},
 {q:"Em qual parte da redação aparece a proposta de intervenção?",a:["Introdução","Desenvolvimento","Conclusão","Título"],c:2},
 {q:"Qual estratégia ajuda na preparação?",a:["Estudar só na véspera","Ignorar os erros","Fazer questões e revisar","Não fazer simulados"],c:2},
 {q:"Qual atitude pode ajudar no dia da prova?",a:["Não dormir","Organizar-se com antecedência","Chegar atrasado","Não conferir o local"],c:1}
];

let atual=0, acertou=0;
const pergunta=document.getElementById("pergunta");
const respostas=document.getElementById("respostas");
const resultado=document.getElementById("resultado");
const proxima=document.getElementById("proxima");
const contador=document.getElementById("contador");
const progressBar=document.getElementById("progressBar");

function carregar(){
  const item=perguntas[atual];
  pergunta.textContent=item.q;
  contador.textContent=`Pergunta ${atual+1} de ${perguntas.length}`;
  progressBar.style.width=`${((atual+1)/perguntas.length)*100}%`;
  resultado.textContent="";
  respostas.innerHTML="";
  proxima.style.display="none";
  item.a.forEach((texto,i)=>{
    const b=document.createElement("button");
    b.className="answer";
    b.textContent=texto;
    b.addEventListener("click",()=>responder(i,b));
    respostas.appendChild(b);
  });
}
function responder(indice,botao){
  const item=perguntas[atual];
  document.querySelectorAll(".answer").forEach((b,i)=>{
    b.disabled=true;
    if(i===item.c)b.classList.add("correct");
  });
  if(indice===item.c){resultado.textContent="✅ Acertou! Mandou bem!";acertou++;}
  else{resultado.textContent="❌ Quase! A resposta correta está destacada em verde." ;botao.classList.add("wrong");}
  proxima.style.display="inline-block";
}
proxima.addEventListener("click",()=>{
  atual++;
  if(atual>=perguntas.length){
    pergunta.textContent=`🏆 Quiz finalizado! Você acertou ${acertou} de ${perguntas.length}.`;
    respostas.innerHTML="";
    resultado.textContent=acertou>=4?"🔥 Excelente! Continue assim!":"💪 Boa! Revise os conteúdos e tente novamente.";
    proxima.textContent="Refazer quiz";
    proxima.style.display="inline-block";
    progressBar.style.width="100%";
    proxima.onclick=()=>{atual=0;acertou=0;proxima.textContent="Próxima pergunta ➜";proxima.onclick=null;carregar();};
  }else carregar();
});
carregar();

const cards=document.querySelectorAll(".info-card,.tips article,.materia");
const observer=new IntersectionObserver(entries=>{
 entries.forEach(entry=>{
  if(entry.isIntersecting){entry.target.classList.add("show");observer.unobserve(entry.target);}
 });
},{threshold:.12});
cards.forEach(card=>{card.style.opacity="0";card.style.transform="translateY(25px)";card.style.transition="opacity .6s ease, transform .6s ease";observer.observe(card);});
const style=document.createElement("style");
style.textContent=".info-card.show,.tips article.show,.materia.show{opacity:1!important;transform:translateY(0)!important}";
document.head.appendChild(style);
